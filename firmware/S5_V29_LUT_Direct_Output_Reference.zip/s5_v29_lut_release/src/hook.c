#include <stddef.h>
#include <stdint.h>
#include "lut_tables.h"

/* Static .bss scratch buffers (keeps RTOS task stack usage < 256 bytes; S5 stack is ~4 KB):
 * - dynamic_lut9 : 9^3 = 729 unpacked uint32 RGB8 entries (2,916 B) from real 0xBEEF octant LUT
 * - v_hi / h_hi  : 2D separable Black Pro-Mist Q4 state (3,002 B) */
static uint32_t dynamic_lut9[9u * 9u * 9u];
static uint16_t v_hi[750];
static uint16_t h_hi[751];

/* Single-cycle ARMv7 Thumb-2 unsigned 8-bit saturate (0..255). */
static inline uint8_t clamp_u8(int v) {
    uint32_t out;
    __asm__("usat %0, #8, %1" : "=r"(out) : "r"(v));
    return (uint8_t)out;
}

/* Single-cycle ARMv7 Thumb-2 signed 8-bit saturate (-128..+127) for real S5 signed NV16 UV. */
static inline int8_t clamp_s8(int v) {
    int32_t out;
    __asm__("ssat %0, #8, %1" : "=r"(out) : "r"(v));
    return (int8_t)out;
}

static inline uint32_t get32(const unsigned char *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static inline unsigned get16(const unsigned char *p) {
    return (unsigned)p[0] | ((unsigned)p[1] << 8);
}

/* Allow both uncached/low (0x06000000+) and high-alias (0x88000000+) DRAM addresses. */
static int valid_plane(uint32_t address, uint32_t bytes, unsigned stride, unsigned width, unsigned height) {
    return address >= 0x06000000u && address < 0xc0000000u &&
           !(address & 31u) && stride >= width && stride <= 8192u &&
           !(stride & 31u) && bytes >= stride * height &&
           bytes <= 64u * 1024u * 1024u && address <= 0xc0000000u - bytes;
}

/* 4x unrolled cache line maintenance:
 * - clean_only=0 (before CPU read): Clean+Invalidate (c7, c14, 1) to protect any dirty lines
 * - clean_only=1 (after CPU write): Clean (c7, c10, 1) to flush modified pixels to DRAM */
static void cache_range(uint32_t address, uint32_t bytes, int clean_only) {
    uint32_t end = address + bytes;
    uint32_t p = address;
    __asm__ volatile("dsb sy" ::: "memory");
    if (clean_only) {
        for (; p + 128u <= end; p += 128u) {
            uint32_t p1 = p + 32u, p2 = p + 64u, p3 = p + 96u;
            __asm__ volatile(
                "mcr p15, 0, %0, c7, c10, 1\n\t"
                "mcr p15, 0, %1, c7, c10, 1\n\t"
                "mcr p15, 0, %2, c7, c10, 1\n\t"
                "mcr p15, 0, %3, c7, c10, 1"
                :: "r"(p), "r"(p1), "r"(p2), "r"(p3) : "memory"
            );
        }
        for (; p < end; p += 32u)
            __asm__ volatile("mcr p15, 0, %0, c7, c10, 1" :: "r"(p) : "memory");
    } else {
        for (; p + 128u <= end; p += 128u) {
            uint32_t p1 = p + 32u, p2 = p + 64u, p3 = p + 96u;
            __asm__ volatile(
                "mcr p15, 0, %0, c7, c14, 1\n\t"
                "mcr p15, 0, %1, c7, c14, 1\n\t"
                "mcr p15, 0, %2, c7, c14, 1\n\t"
                "mcr p15, 0, %3, c7, c14, 1"
                :: "r"(p), "r"(p1), "r"(p2), "r"(p3) : "memory"
            );
        }
        for (; p < end; p += 32u)
            __asm__ volatile("mcr p15, 0, %0, c7, c14, 1" :: "r"(p) : "memory");
    }
    __asm__ volatile("dsb sy" ::: "memory");
}

/* Unpack real DC-S5 0xBEEF 9^3 octant LUT (729 nodes, 2,920 B total) using 0x86E39EB4 map. */
static void unpack_beef_lut9(const uint16_t *src, uint32_t *dst) {
    for (unsigned i = 0; i < 9u * 9u * 9u; ++i) {
        unsigned off = beef9_slot_off[i];
        uint32_t w0 = src[off * 2u];
        uint32_t w1 = src[off * 2u + 1u];
        uint32_t r6 = w0 & 0x3Fu;
        uint32_t b6 = (w0 >> 6) & 0x3Fu;
        uint32_t g6 = ((w0 >> 12) & 0x0Fu) | ((w1 & 0x03u) << 4);
        uint32_t r8 = (r6 << 2) | (r6 >> 4);
        uint32_t g8 = (g6 << 2) | (g6 >> 4);
        uint32_t b8 = (b6 << 2) | (b6 >> 4);
        dst[i] = r8 | (g8 << 8) | (b8 << 16);
    }
}

/* Real DC-S5 slot pointers at 0x08A9D47C[0..4] reside in 0x062B6000..0x062B9000. */
static const uint16_t *active_slot_lut9(uint32_t lut_id) {
    if (lut_id < 1u || lut_id >= 8u)
        return NULL;
    const volatile uint32_t *slot_ptrs = (const volatile uint32_t *)(uintptr_t)0x08a9d47cu;
    uint32_t buf_addr = slot_ptrs[lut_id];
    if (buf_addr < 0x06000000u || buf_addr >= 0xc0000000u || (buf_addr & 3u))
        return NULL;
    const uint16_t *hdr = (const uint16_t *)(uintptr_t)buf_addr;
    if (hdr[0] != 0xbeefu || hdr[1] != 1u)
        return NULL;
    return hdr + 2;
}

static inline void sample_tetra_core(const uint32_t *p, int rw, int gw, int bw,
                                     unsigned sg, unsigned sb, int out[3]) {
    uint32_t v0 = p[0];
    uint32_t v3 = p[sb + sg + 1u];
    uint32_t v1, v2;
    int w1, w2, w3;

    if (rw >= gw) {
        if (gw >= bw) {
            v1 = p[1];       v2 = p[sg + 1u];      w1 = rw; w2 = gw; w3 = bw;
        } else if (rw >= bw) {
            v1 = p[1];       v2 = p[sb + 1u];      w1 = rw; w2 = bw; w3 = gw;
        } else {
            v1 = p[sb];      v2 = p[sb + 1u];      w1 = bw; w2 = rw; w3 = gw;
        }
    } else {
        if (bw > gw) {
            v1 = p[sb];      v2 = p[sb + sg];      w1 = bw; w2 = gw; w3 = rw;
        } else if (bw > rw) {
            v1 = p[sg];      v2 = p[sb + sg];      w1 = gw; w2 = bw; w3 = rw;
        } else {
            v1 = p[sg];      v2 = p[sg + 1u];      w1 = gw; w2 = rw; w3 = bw;
        }
    }

    int r0 = (int)(v0 & 0xFFu), r1 = (int)(v1 & 0xFFu), r2 = (int)(v2 & 0xFFu), r3 = (int)(v3 & 0xFFu);
    int g0 = (int)((v0 >> 8) & 0xFFu), g1 = (int)((v1 >> 8) & 0xFFu), g2 = (int)((v2 >> 8) & 0xFFu), g3 = (int)((v3 >> 8) & 0xFFu);
    int b0 = (int)(v0 >> 16), b1 = (int)(v1 >> 16), b2 = (int)(v2 >> 16), b3 = (int)(v3 >> 16);

    out[0] = r0 + (((r1 - r0) * w1 + (r2 - r1) * w2 + (r3 - r2) * w3 + 128) >> 8);
    out[1] = g0 + (((g1 - g0) * w1 + (g2 - g1) * w2 + (g3 - g2) * w3 + 128) >> 8);
    out[2] = b0 + (((b1 - b0) * w1 + (b2 - b1) * w2 + (b3 - b2) * w3 + 128) >> 8);
}

static inline void sample_lut17_tetra(const uint32_t *lut, unsigned r, unsigned g, unsigned b, int out[3]) {
    const uint32_t *p = lut + lut17_b[b].off + lut17_g[g].off + lut17_r[r].off;
    sample_tetra_core(p, (int)lut17_r[r].w, (int)lut17_g[g].w, (int)lut17_b[b].w, 17u, 289u, out);
}

static inline void sample_lut9_tetra(const uint32_t *lut, unsigned r, unsigned g, unsigned b, int out[3]) {
    const uint32_t *p = lut + lut9_b[b].off + lut9_g[g].off + lut9_r[r].off;
    sample_tetra_core(p, (int)lut9_r[r].w, (int)lut9_g[g].w, (int)lut9_b[b].w, 9u, 81u, out);
}

static inline void sample_active_lut(int use_lut9, const uint32_t *lut,
                                     unsigned r, unsigned g, unsigned b, int out[3]) {
    if (use_lut9)
        sample_lut9_tetra(lut, r, g, b, out);
    else
        sample_lut17_tetra(lut, r, g, b, out);
}

int image_hook(uint32_t image_id, unsigned char *description) {
    int (*get_description)(uint32_t, unsigned char *) =
        (void *)(uintptr_t)0x87864acdu;
    int status = get_description(image_id, description);
    const volatile uint32_t *view_assist_type =
        (const volatile uint32_t *)(uintptr_t)0x08bdc310u;
    unsigned width  = get16(description + 0x1c);
    unsigned height = get16(description + 0x1e);
    /* Support all native S5 still aspect ratios (L/M/S including 65:24 S 2400x888)
     * while skipping small thumbnails/previews (<1600px wide or <720px tall). */
    if (status || *view_assist_type != 1u || get32(description + 0x20) != 2u ||
        width < 1600u || width > 6000u || (width & 1u) ||
        height < 720u || height > 4000u || (height & 1u))
        return status;

    uint32_t y_address = get32(description), c_address = get32(description + 12);
    unsigned y_stride = get16(description + 8), c_stride = get16(description + 20);
    uint32_t y_bytes = get32(description + 4), c_bytes = get32(description + 16);
    if (!valid_plane(y_address, y_bytes, y_stride, width, height) ||
        !valid_plane(c_address, c_bytes, c_stride, width, height) ||
        !(y_address + y_bytes <= c_address || c_address + c_bytes <= y_address))
        return status;

    uint32_t lut_id = *(const volatile uint32_t *)(uintptr_t)0x08bdc330u;
    const uint32_t *active_lut = film_lut17;
    int use_lut9 = 0;
    const uint16_t *raw_slot = active_slot_lut9(lut_id);
    if (raw_slot) {
        unpack_beef_lut9(raw_slot, dynamic_lut9);
        active_lut = dynamic_lut9;
        use_lut9 = 1;
    }

    int mist_grain_en = (*(const volatile uint32_t *)(uintptr_t)0x08bdc314u == 1u);

    cache_range(y_address, y_stride * height, 0);
    cache_range(c_address, c_stride * height, 0);

    unsigned blocks = width >> 3;
    unsigned blk_end = blocks << 3;
    if (mist_grain_en) {
        volatile uint16_t *vz = v_hi;
        for (unsigned i = 0; i < blocks; ++i)
            vz[i] = 0u;
    }

    uint32_t rng = (0x9E3779B9u ^ (image_id * 0x85EBCA6Bu)) | 1u;

    for (unsigned row = 0; row < height; ++row) {
        unsigned char *y = (void *)(uintptr_t)(y_address + row * y_stride);
        int8_t *c = (int8_t *)(uintptr_t)(c_address + row * c_stride);

        if (!mist_grain_en) {
            /* Fast pure-LUT path: fused 2-pixel signed-UV NV16 + tetrahedral lookup. */
            if (use_lut9) {
                for (unsigned x = 0; x < width; x += 2u) {
                    int y0 = y[x], y1 = y[x + 1u];
                    int cb = (int)c[x], cr = (int)c[x + 1u];
                    int dr = (359 * cr + 128) >> 8;
                    int dg = (88 * cb + 183 * cr + 128) >> 8;
                    int db = (454 * cb + 128) >> 8;

                    int rgb0[3], rgb1[3];
                    sample_lut9_tetra(active_lut,
                                      clamp_u8(y0 + dr), clamp_u8(y0 - dg), clamp_u8(y0 + db), rgb0);
                    sample_lut9_tetra(active_lut,
                                      clamp_u8(y1 + dr), clamp_u8(y1 - dg), clamp_u8(y1 + db), rgb1);

                    y[x]      = clamp_u8((77 * rgb0[0] + 150 * rgb0[1] + 29 * rgb0[2] + 128) >> 8);
                    y[x + 1u] = clamp_u8((77 * rgb1[0] + 150 * rgb1[1] + 29 * rgb1[2] + 128) >> 8);
                    int sr = rgb0[0] + rgb1[0], sg = rgb0[1] + rgb1[1], sb = rgb0[2] + rgb1[2];
                    c[x]      = clamp_s8((-43 * sr - 85 * sg + 128 * sb + 256) >> 9);
                    c[x + 1u] = clamp_s8((128 * sr - 107 * sg - 21 * sb + 256) >> 9);
                }
            } else {
                for (unsigned x = 0; x < width; x += 2u) {
                    int y0 = y[x], y1 = y[x + 1u];
                    int cb = (int)c[x], cr = (int)c[x + 1u];
                    int dr = (359 * cr + 128) >> 8;
                    int dg = (88 * cb + 183 * cr + 128) >> 8;
                    int db = (454 * cb + 128) >> 8;

                    int rgb0[3], rgb1[3];
                    sample_lut17_tetra(active_lut,
                                       clamp_u8(y0 + dr), clamp_u8(y0 - dg), clamp_u8(y0 + db), rgb0);
                    sample_lut17_tetra(active_lut,
                                       clamp_u8(y1 + dr), clamp_u8(y1 - dg), clamp_u8(y1 + db), rgb1);

                    y[x]      = clamp_u8((77 * rgb0[0] + 150 * rgb0[1] + 29 * rgb0[2] + 128) >> 8);
                    y[x + 1u] = clamp_u8((77 * rgb1[0] + 150 * rgb1[1] + 29 * rgb1[2] + 128) >> 8);
                    int sr = rgb0[0] + rgb1[0], sg = rgb0[1] + rgb1[1], sb = rgb0[2] + rgb1[2];
                    c[x]      = clamp_s8((-43 * sr - 85 * sg + 128 * sb + 256) >> 9);
                    c[x + 1u] = clamp_s8((128 * sr - 107 * sg - 21 * sb + 256) >> 9);
                }
            }
        } else {
            /* Tetrahedral LUT + Seamless 2D Black Pro-Mist + Midtone-weighted Film Grain. */
            unsigned any_bloom = 0u;
            for (unsigned bx = 0; bx < blocks; ++bx) {
                unsigned base_x = bx << 3;
                unsigned hi_sum = 0u;
                for (unsigned x = base_x; x < base_x + 8u; x += 2u) {
                    int y0 = y[x], y1 = y[x + 1u];
                    int cb = (int)c[x], cr = (int)c[x + 1u];
                    int dr = (359 * cr + 128) >> 8;
                    int dg = (88 * cb + 183 * cr + 128) >> 8;
                    int db = (454 * cb + 128) >> 8;

                    int rgb0[3], rgb1[3];
                    sample_active_lut(use_lut9, active_lut,
                                      clamp_u8(y0 + dr), clamp_u8(y0 - dg), clamp_u8(y0 + db), rgb0);
                    sample_active_lut(use_lut9, active_lut,
                                      clamp_u8(y1 + dr), clamp_u8(y1 - dg), clamp_u8(y1 + db), rgb1);

                    unsigned ny0 = clamp_u8((77 * rgb0[0] + 150 * rgb0[1] + 29 * rgb0[2] + 128) >> 8);
                    unsigned ny1 = clamp_u8((77 * rgb1[0] + 150 * rgb1[1] + 29 * rgb1[2] + 128) >> 8);
                    y[x]      = (uint8_t)ny0;
                    y[x + 1u] = (uint8_t)ny1;
                    int sr = rgb0[0] + rgb1[0], sg = rgb0[1] + rgb1[1], sb = rgb0[2] + rgb1[2];
                    c[x]      = clamp_s8((-43 * sr - 85 * sg + 128 * sb + 256) >> 9);
                    c[x + 1u] = clamp_s8((128 * sr - 107 * sg - 21 * sb + 256) >> 9);

                    if (ny0 > 200u) hi_sum += ny0 - 200u;
                    if (ny1 > 200u) hi_sum += ny1 - 200u;
                }
                unsigned cur_hi = hi_sum << 2; /* Q4 fixed-point: 0..1760 */
                unsigned v_decay = ((unsigned)v_hi[bx] * 7u + 4u) >> 3;
                unsigned v_val = (cur_hi > v_decay) ? ((v_decay + cur_hi + 1u) >> 1) : v_decay;
                v_hi[bx] = (uint16_t)v_val;
                any_bloom |= v_val;
            }
            for (unsigned x = blk_end; x < width; x += 2u) {
                int y0 = y[x], y1 = y[x + 1u];
                int cb = (int)c[x], cr = (int)c[x + 1u];
                int dr = (359 * cr + 128) >> 8;
                int dg = (88 * cb + 183 * cr + 128) >> 8;
                int db = (454 * cb + 128) >> 8;
                int rgb0[3], rgb1[3];
                sample_active_lut(use_lut9, active_lut,
                                  clamp_u8(y0 + dr), clamp_u8(y0 - dg), clamp_u8(y0 + db), rgb0);
                sample_active_lut(use_lut9, active_lut,
                                  clamp_u8(y1 + dr), clamp_u8(y1 - dg), clamp_u8(y1 + db), rgb1);
                y[x]      = clamp_u8((77 * rgb0[0] + 150 * rgb0[1] + 29 * rgb0[2] + 128) >> 8);
                y[x + 1u] = clamp_u8((77 * rgb1[0] + 150 * rgb1[1] + 29 * rgb1[2] + 128) >> 8);
                int sr = rgb0[0] + rgb1[0], sg = rgb0[1] + rgb1[1], sb = rgb0[2] + rgb1[2];
                c[x]      = clamp_s8((-43 * sr - 85 * sg + 128 * sb + 256) >> 9);
                c[x + 1u] = clamp_s8((128 * sr - 107 * sg - 21 * sb + 256) >> 9);
            }

            if (any_bloom) {
                /* Bidirectional horizontal IIR (~24px soft 2D halo, zero tile seams) */
                unsigned acc = v_hi[0];
                for (unsigned bx = 0; bx < blocks; ++bx) {
                    acc = (acc * 3u + v_hi[bx] + 2u) >> 2;
                    h_hi[bx] = (uint16_t)acc;
                }
                acc = h_hi[blocks - 1u];
                for (int bx = (int)blocks - 1; bx >= 0; --bx) {
                    acc = (acc * 3u + h_hi[bx] + 2u) >> 2;
                    h_hi[bx] = (uint16_t)acc;
                }
                h_hi[blocks] = h_hi[blocks - 1u];

                uint32_t s = rng;
                for (unsigned bx = 0; bx < blocks; ++bx) {
                    unsigned b0 = h_hi[bx], b1 = h_hi[bx + 1u];
                    unsigned char *yb = y + (bx << 3);
                    int8_t *cb_ptr = c + (bx << 3);
                    for (unsigned k = 0; k < 8u; k += 2u) {
                        unsigned bloom0 = (b0 * (8u - k) + b1 * k + 128u) >> 8;
                        unsigned bloom1 = (b0 * (7u - k) + b1 * (k + 1u) + 128u) >> 8;

                        s ^= s << 13; s ^= s >> 17; s ^= s << 5;
                        int g0 = (int)(s & 7u) - 3;
                        int g1 = (int)((s >> 8) & 7u) - 3;

                        int l0 = yb[k], l1 = yb[k + 1u];
                        int w0 = (l0 * (255 - l0)) >> 13; /* 0..2 */
                        int w1 = (l1 * (255 - l1)) >> 13;
                        yb[k]      = clamp_u8(l0 + (int)bloom0 + ((g0 * (w0 + 1)) >> 1));
                        yb[k + 1u] = clamp_u8(l1 + (int)bloom1 + ((g1 * (w1 + 1)) >> 1));
                        if (bloom0 | bloom1)
                            cb_ptr[k + 1u] = clamp_s8((int)cb_ptr[k + 1u] + (int)((bloom0 + bloom1) >> 4));
                    }
                }
                for (unsigned x = blk_end; x < width; x += 2u) {
                    s ^= s << 13; s ^= s >> 17; s ^= s << 5;
                    int g0 = (int)(s & 7u) - 3;
                    int g1 = (int)((s >> 8) & 7u) - 3;
                    int l0 = y[x], l1 = y[x + 1u];
                    int w0 = (l0 * (255 - l0)) >> 13;
                    int w1 = (l1 * (255 - l1)) >> 13;
                    y[x]      = clamp_u8(l0 + ((g0 * (w0 + 1)) >> 1));
                    y[x + 1u] = clamp_u8(l1 + ((g1 * (w1 + 1)) >> 1));
                }
                rng = s;
            } else {
                /* Fast grain-only pass when entire row has zero highlight bloom */
                uint32_t s = rng;
                for (unsigned x = 0; x < width; x += 2u) {
                    s ^= s << 13; s ^= s >> 17; s ^= s << 5;
                    int g0 = (int)(s & 7u) - 3;
                    int g1 = (int)((s >> 8) & 7u) - 3;
                    int l0 = y[x], l1 = y[x + 1u];
                    int w0 = (l0 * (255 - l0)) >> 13;
                    int w1 = (l1 * (255 - l1)) >> 13;
                    y[x]      = clamp_u8(l0 + ((g0 * (w0 + 1)) >> 1));
                    y[x + 1u] = clamp_u8(l1 + ((g1 * (w1 + 1)) >> 1));
                }
                rng = s;
            }
        }
    }

    cache_range(y_address, y_stride * height, 1);
    cache_range(c_address, c_stride * height, 1);
    return status;
}
