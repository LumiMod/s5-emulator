# Panasonic DC-S5 (V2.9 / MC801) 机内照片 LUT 直出 + 二维黑柔/颗粒 参考实现包

本目录是从 S5 V2.9 综合实验固件中单独拆出的 **机内 JPEG 3D LUT 直出子系统**，供技术交流与二次开发参考。不包含录像解锁、码率修改、`rootfs1` 脚本或任何原厂专有二进制/解密密钥。

> **状态声明（v2 真机规格修正版）**：已根据 DC-S5 真机实测反馈修正了全部 6 项硬件规格差异（有符号 `int8_t` NV16 UV、真实 `0x062B6000..` 槽位地址、真实 `9³ = 729` 节点 `0x86E39EB4` 八分体 `0xBEEF` LUT、216 字节极小栈帧、`Clean+Invalidate` 缓存维护及低位地址兼容），并通过严格 4 KB 栈保护下的 Unicorn ARM 全套验证；本实现仍待上真机实拍验收，建议优先通过 Service USB 纯 RAM 验证，勿直接裸刷 NAND。

---

## 一、目录结构

```text
s5_v29_lut_release/
├── README.md                     # 本文档（架构、内存映射、代码逐模块解析、构建与验证）
├── src/
│   ├── hook.c                    # 核心 C 源码（入口守卫、0xbeef 自动解包、17³ 四面体、2D 黑柔/颗粒）
│   └── lut_tables.h              # 预生成的 17³ 预乘轴表 + 打包版内置 FilmLook 17³ 表
├── tools/
│   ├── gen_lut_tables.py         # 从 33³ 16-bit LUT 生成 17³ 打包表与轴表
│   ├── build_lut_patch.py        # 编译 hook.c、链接 payload、修补 07_postboot3.bin 与 20_osdover.bin
│   └── verify_lut_emulation.py   # Unicorn ARM 仿真测试套件（8 组功能与边界用例）
└── prebuilt/
    ├── payload.bin               # 预编译好的纯补丁体（47,060 B，可直接反汇编参考）
    └── manifest.json             # 注入点地址、UI 偏移与构建摘要
```

---

## 二、总体工作原理与数据流

### 1. 注入点与调用拦截（`07_postboot3.bin`）

S5 拍照生成 JPEG 前，主控会通过 `07_postboot3.bin`（加载基址 `0x87707000`）获取待编码的 NV16 图像平面描述符（Y 平面地址/步长/大小、CbCr 交错平面地址/步长/大小、图像宽高与像素格式枚举）。

* **原始调用点**：`0x877537A2` 处原指令为 `BL 0x87864ACC`（图像描述符获取函数 `get_description(image_id, description)`）。
* **补丁劫持**：将 `0x877537A2` 改写为 `BL image_hook`（位于 `0x879F7900` 处的 `0xFF` 空洞区 `CAVE`）。
* **执行顺序**：
  ```text
  JPEG 编码管线
    └─▶ 0x877537A2: BL image_hook (0x879F7900 代码洞)
          ├─ 1. 先调用原厂 get_description(image_id, description) 拿到原始 NV16 描述符
          ├─ 2. 检查总开关 / 像素格式 / 宽高范围 / 平面合法性（不满足则零开销直接返回）
          ├─ 3. 根据当前 LUT 槽位选择内置 17³ 表，或自动解包 SD 卡导入的 0xbeef 17³ 表
          ├─ 4. D-Cache Invalidate → 原地处理 NV16 Y/CbCr 平面 → D-Cache Clean
          └─ 5. 返回原始 status 给原厂 JPEG 硬件编码器继续编码落盘
  ```
* **零取景/录像侵入**：入口只处理静态照片尺寸（`1600..6000 × 720..4000` 且格式枚举 `== 2`），实时取景、缩略图、视频帧均直接跳过。

---

### 2. 机内 UI 与原厂内存状态复用（`20_osdover.bin` + `AVIO` 状态区）

为了不手写复杂的 OpenVG 菜单控件，本方案直接复用原厂 **`V-Log 查看助手`** 菜单的两个开关和 **`LUT 选择`** 槽位（地址源自 `03_program.bin` 中 `AVIO_ViewAssistSet` 的状态结构体）：

| 内存地址 | 原厂含义 | 补丁后用途 | `20_osdover.bin` 改名（简中 / 繁中 / 英文） |
| :--- | :--- | :--- | :--- |
| `0x08BDC310` | `LUT查看助手(监视器)` | **LUT 直出总开关**（`== 1` 启用） | `FilmLook直出试验` / `FilmLook直出試驗` / `FilmLook JPEG (TEST)` |
| `0x08BDC314` | `LUT查看助手(HDMI)` | **黑柔 + 胶片颗粒独立开关**（`== 1` 启用） | `黑柔+胶片颗粒(试验)` / `黑柔+膠片顆粒(試驗)` / `BlackMist+Grain (TEST)` |
| `0x08BDC330` | 当前选中的 LUT 槽位号 | `0` = 内置 FilmLook；`1..7` = SD 卡导入槽位 | 复用原厂 `LUT 选择` 菜单，无需改名 |
| `0x08A9D47C[slot]` | 各槽位 `0xbeef` LUT 缓冲区指针表 | 槽位 `1..7` 有效时自动读取并解包 | 复用原厂 SD 卡 `.cube` 导入流程 |

`20_osdover.bin` 中全部 6 处 UTF-16LE 菜单槽位偏移（保持原槽位字节长度与 `\x00\x00` 终止符）：
* 英文 `LUT View Assist (Monitor)`：`0x5708A2`（槽长 50 字节） / `LUT View Assist (HDMI)`：`0x5708D6`（槽长 44 字节）
* 简中 `LUT查看助手(监视器)`：`0x881752`（槽长 24 字节） / `LUT查看助手(HDMI)`：`0x88176C`（槽长 26 字节）
* 繁中 `LUT檢視輔助(監視器)`：`0x93963E`（槽长 24 字节） / `LUT檢視輔助(HDMI)`：`0x939658`（槽长 26 字节）

---

## 三、核心代码工作逻辑详解（`src/hook.c`）

### 1. 入口安全守卫与全画幅比例自适应（`valid_plane` + `image_hook`）
* 读取 `width = get16(description + 0x1c)`、`height = get16(description + 0x1e)` 与格式 `get32(description + 0x20) == 2`。
* 允许范围：`width ∈ [1600, 6000]`、`height ∈ [720, 4000]` 且为偶数——覆盖 S5 原厂所有静态纵横比（`3:2`、`4:3`、`16:9`、`1:1`、原厂 `65:24` XPan、`2:1` 及 L/M/S 尺寸），同时跳过 `640×480` 等缩略图。
* `valid_plane()` 检查：平面地址位于 DRAM 有效区 `[0x88000000, 0xC0000000)`、32 字节（Cache Line）对齐、`stride ∈ [width, 8192]`、容量足够且 Y/C 两平面内存区间不重叠。

### 2. D-Cache 一致性维护（`cache_range`）
* ISP 写完 NV16 图像到 DRAM 后、CPU 读取之前，执行 **D-Cache Clean+Invalidate**（`mcr p15, 0, p, c7, c14, 1`），防止缓存行中已有脏数据丢失；
* CPU 改写完像素、交给 JPEG 硬件编码器之前，执行 **D-Cache Clean**（`mcr p15, 0, p, c7, c10, 1`）；
* 前后均加 `dsb sy` 内存屏障，循环做 **4× 展开**（每步 128 字节，按 32 字节步进，兼容 32B/64B 缓存行）。

### 3. 外部导入 LUT 自动机内解包（`active_slot_lut9` + `unpack_beef_lut9`）
* 当 `lut_id ∈ [1, 7]` 时，读取 `0x08A9D47C[lut_id]`（真实地址区间位于 `0x062B6000..0x062B9000`，地址校验下限已修正为 `0x06000000`），验证魔数 `hdr[0] == 0xbeef && hdr[1] == 1`。
* DC-S5 固件 `AVIO_ReadLUTFile`（`0x867be2da`）载入 SD 卡 `.vlt`/`.cube` 后，会只保留偶数网格压缩为 **`9×9×9 = 729` 节点**（总长 `2,920` 字节，槽位步长 `0xC00`），并经 `0x86E39EB4` 八分体查表按 `(G, B, R)` 重排到 8 个奇偶八分体（`125/100/100/80/100/80/80/64`）。
* 每次处理照片前通过预提取的 `beef9_slot_off[729]` 表一次性解包 729 个节点到 `.bss` 静态区 `dynamic_lut9[729]`（仅 **2,916 B**，耗时 `<0.015 ms`），随后走 `9³` 四面体插值；槽位 `0` 使用只读内置 `film_lut17[4913]`（`17³` 四面体插值）。

### 4. 有符号 `int8_t` NV16 与 216 字节极小 RTOS 栈
* **有符号色度**：DC-S5 真机 NV16 的 Cb/Cr 平面为**有符号 `int8_t`（`-128..+127`，中性灰 = `0x00`）**，不再做 `- 128` / `+ 128` 偏置，回写及黑柔暖色晕染均使用 ARMv7 Thumb-2 单周期有符号饱和指令 `ssat #8`。
* **极小栈帧**：将 `v_hi[750]`、`h_hi[751]` 与 `dynamic_lut9[729]` 全部移至静态 `.bss` 区，`image_hook` 实测栈帧仅 **216 字节**（`push 9 regs` + `sub sp, #0xb4`），安全适配 S5 编码任务仅 ~4 KB 的 RTOS 栈。
* **回放防双重套 LUT**：若开启监视器开关后需要避免机内回放画面再叠一遍监看 LUT，可配套修补 `03_program.bin` `0x866AE770` 处回放 View Assist 逻辑（本纯 LUT 包未修改 `03_program.bin`）。

### 4. L1 缓存友好 `17³` 四面体插值（`sample_lut17_tetra`）
这是性能提升的核心（相比原始 `33³` 三线性原型，指令数压缩至原来的 **1/3.54**）：
* **零除法轴查表**：`lut_tables.h` 中的 `lut17_r/g/b[256]` 预计算好每个 8-bit 通道对应的网格偏移（已预乘步长 `1 / 17 / 289`）与定点小数权重 `w ∈ [0, 256]`。
* **单指令取色 + 4 角点四面体插值**：
  * 每个节点是 4 字节对齐的 `uint32_t`，一次 `ldr` 同时读出 R/G/B；
  * 根据 `(rw, gw, bw)` 大小关系落入单位立方体的 6 个四面体之一，仅取 `v0=p[0]`、`v3=p[307]` 及中间 2 个角点 `v1, v2`；
  * 每通道仅 3 次乘加：
    ```c
    out[c] = c0 + (((c1 - c0) * w1 + (c2 - c1) * w2 + (c3 - c2) * w3 + 128) >> 8);
    ```
  * 整张 `17³` 查表仅 `19.2 KB`，可完整常驻 Cortex-A7 的 `32 KB` L1 数据缓存；输出饱和使用 ARMv7 Thumb-2 单周期 `usat` 指令。

### 5. 双像素 NV16 寄存器融合
* NV16 为 4:2:2 采样（每两个水平相邻像素 `x, x+1` 共用一对 `Cb, Cr`）。
* 每次循环同步解码两个像素，共用 `dr/dg/db` 色度增量，查完 LUT 后合并计算 `sr/sg/sb` 一次写回 `Cb/Cr`，减少一半色度内存访问与算术指令。

### 6. 无缝二维黑柔（Q4 定点 IIR）+ 中间调加权颗粒
当 `0x08BDC314 == 1` 时进入特效路径（关闭时走独立纯净 LUT 循环，零分支损耗）：
1. **高光提取与垂直平滑**：按 8 像素水平降采样（每行最多 750 块，3 KB 栈空间），累计 `Y > 200` 的高光超额量并放大为 Q4 定点（`hi_sum << 2`，避免低精度截断吞光）；跨行采用快起慢衰垂直 IIR（`v_decay = (v_hi * 7 + 4) >> 3`）。
2. **整行双向水平 IIR（零分块接缝）**：若整行存在高光（`any_bloom != 0`），先从左到右、再从右到左各做一遍 `(acc * 3 + x + 2) >> 2` 平滑，形成约 24px 半径的对称二维柔光光晕，最后线性插值叠加到像素亮度并对 `Cr` 加微弱暖色晕染。
3. **快速纯颗粒通道**：若整行无高光，跳过双向 IIR，直接走 xorshift32 伪随机颗粒循环；颗粒强度按抛物线权重 `w = (Y * (255 - Y)) >> 13` 自动在暗部与高光衰减，集中在中灰调。

---

## 四、编译、构建与仿真验证

### 依赖环境
* `clang`（支持 `--target=armv7-none-eabi`）
* Python 3.9+，以及 `capstone`、`pyelftools`、`unicorn`

### 1. 编译并生成补丁（需要你本地已解密的 `07_postboot3.bin` 与 `20_osdover.bin`）
```bash
python3 tools/build_lut_patch.py \
  --postboot3-in  /path/to/07_postboot3.bin \
  --osdover-in    /path/to/20_osdover.bin \
  --out-dir       ./out
```
> 若你只想生成纯 `payload.bin` 做反汇编/检查，不传入 `--postboot3-in` 和 `--osdover-in` 即可：
> ```bash
> python3 tools/build_lut_patch.py --out-dir ./out
> ```

### 2. 运行 Unicorn ARM 仿真验证（8 组用例）
```bash
python3 tools/verify_lut_emulation.py \
  --program    /path/to/03_program.bin \
  --postboot3  ./out/07_postboot3.bin \
  --payload    ./out/payload.bin \
  --manifest   ./out/manifest.json
```

### 3. Unicorn ARM 实测指令效率对比（`6000×4000` 全画幅）

| 版本 | 1,200 万指令完成像素 | 单像素指令数 | 相对原始原型 | 实机单张估算（Cortex-A7） |
| :--- | :--- | :--- | :--- | :--- |
| 原始 `33³` 三线性原型（仅纯 LUT） | `17,040 px` | `~450+` | `1.00×` | ~13 – 22 秒 |
| 优化 `33³` 三线性版（仅纯 LUT） | `41,482 px` | `180.5` | `2.43×` | ~5 – 9 秒 |
| **本版 `17³` 四面体（纯 LUT，`mist=0`）** | **`60,384 px`** | **`124.0`** | **`3.54×`** | **~3 – 5.5 秒** |
| **本版 `17³` 四面体（LUT+2D黑柔+颗粒，`mist=1`）** | **`51,932 px`** | **`144.9`** | **`3.05×`** | **~3.5 – 6.5 秒** |

---

## 五、已知限制与实机注意事项

1. **未重签固件**：外层 `S5___V29.bin` 更新包受 ECDSA P-256 签名保护，建议优先通过服务模式在 RAM 中验证单个补丁，切勿直接将未验证的整包写入 NAND。
2. **`.bss` 可写性假设**：外部导入槽位 `LUT1`–`LUT4` 会写入 `CAVE` 末尾的 `.bss` 区 `dynamic_lut17`；若实机 MMU 将 `07_postboot3` 代码区映射为只读（RX），槽位 0（只读 `film_lut17`）仍可用，但槽位 `1..7` 需将 `dynamic_lut17` 改址到明确可写的 DRAM 缓冲区。
3. **菜单可用条件**：复用原厂 `V-Log 查看助手` 开关意味着在非 V-Log 照片风格下，原厂菜单可能会灰选该项（如需全风格解锁，需在 `03_program.bin` 中额外放开菜单使能判断）。
4. **仅限静态照片**：CPU 软算适用于单张静照直出，视频实时 LUT 必须走硬件 ISP/IPU 通道。
