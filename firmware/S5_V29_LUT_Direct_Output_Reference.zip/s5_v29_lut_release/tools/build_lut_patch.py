#!/usr/bin/env python3
"""Build standalone S5 V2.9 LUT direct-output payload, 07_postboot3.bin, and 20_osdover.bin."""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
import subprocess
from pathlib import Path
from capstone import Cs, CS_ARCH_ARM, CS_MODE_THUMB
from elftools.elf.elffile import ELFFile

CAVE = 0x879F7900
MODULE = 0x87707000
CALL = 0x877537A2
ORIGINAL_GETTER = 0x87864ACC

# UTF-16LE UI slot patches in 20_osdover.bin (relative to factory V2.9 20_osdover.bin)
UI_PATCHES = (
    # Monitor switch (0x08bdc310): LUT direct output master toggle
    (0x5708A2, 50, "LUT View Assist (Monitor)", "FilmLook JPEG (TEST)"),
    (0x881752, 24, "LUT查看助手(监视器)", "FilmLook直出试验"),
    (0x93963E, 24, "LUT檢視輔助(監視器)", "FilmLook直出試驗"),
    # HDMI switch (0x08bdc314): BlackMist + Film Grain independent toggle
    (0x5708D6, 44, "LUT View Assist (HDMI)", "BlackMist+Grain (TEST)"),
    (0x88176C, 26, "LUT查看助手(HDMI)", "黑柔+胶片颗粒(试验)"),
    (0x939658, 26, "LUT檢視輔助(HDMI)", "黑柔+膠片顆粒(試驗)"),
)


def sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def make_bl(source: int, target: int) -> bytes:
    disp = target - (source + 4)
    assert disp % 2 == 0 and -(1 << 24) <= disp < (1 << 24)
    val = disp & 0x1FFFFFF
    s, i1, i2 = (val >> 24) & 1, (val >> 23) & 1, (val >> 22) & 1
    hw1 = 0xF000 | (s << 10) | ((val >> 12) & 0x3FF)
    hw2 = 0xD000 | ((1 ^ s ^ i1) << 13) | ((1 ^ s ^ i2) << 11) | ((val >> 1) & 0x7FF)
    code = struct.pack("<HH", hw1, hw2)
    insn = next(Cs(CS_ARCH_ARM, CS_MODE_THUMB).disasm(code, source))
    assert insn.mnemonic == "bl" and int(insn.op_str[1:], 16) == target
    return code


def compile_and_link_payload(hook_c: Path, out_dir: Path) -> tuple[bytes, int, dict]:
    hook_o = out_dir / "hook.o"
    payload_bin = out_dir / "payload.bin"
    cmd = [
        "clang", "--target=armv7-none-eabi", "-mcpu=cortex-a7", "-mthumb",
        "-mno-movt", "-mfpu=none", "-mfloat-abi=soft", "-fno-vectorize",
        "-fno-slp-vectorize", "-ffreestanding", "-fno-builtin", "-fno-stack-protector",
        "-O3", "-c", str(hook_c), "-o", str(hook_o),
    ]
    subprocess.run(cmd, check=True)

    with hook_o.open("rb") as f:
        elf = ELFFile(f)
        text = elf.get_section_by_name(".text")
        rodata = elf.get_section_by_name(".rodata")
        data_sec = elf.get_section_by_name(".data")
        bss_sec = elf.get_section_by_name(".bss")
        symtab = elf.get_section_by_name(".symtab")

        undefs = [s.name for s in symtab.iter_symbols() if s["st_shndx"] == "SHN_UNDEF" and s.name]
        assert not undefs, f"Undefined external symbols in hook.o: {undefs}"
        divs = [i for i in Cs(CS_ARCH_ARM, CS_MODE_THUMB).disasm(text.data(), 0) if i.mnemonic in ("udiv", "sdiv")]
        assert not divs, f"Unexpected hardware division instructions: {len(divs)}"

        payload = bytearray()
        sec_bases: dict[str, int] = {}

        def append_sec(name: str, raw: bytes) -> None:
            pad = (4 - len(payload) % 4) % 4
            if pad:
                payload.extend(b"\x00" * pad)
            sec_bases[name] = CAVE + len(payload)
            payload.extend(raw)

        append_sec(".text", text.data())
        if rodata and rodata["sh_size"] > 0:
            append_sec(".rodata", rodata.data())
        if data_sec and data_sec["sh_size"] > 0:
            append_sec(".data", data_sec.data())
        if bss_sec and bss_sec["sh_size"] > 0:
            append_sec(".bss", b"\x00" * bss_sec["sh_size"])

        hook_entry = None
        for sym in symtab.iter_symbols():
            if sym.name == "image_hook":
                hook_entry = sec_bases[".text"] + sym["st_value"]
        assert hook_entry is not None, "image_hook symbol not found"

        for rel_name in (".rel.text", ".rela.text"):
            rel_sec = elf.get_section_by_name(rel_name)
            if not rel_sec:
                continue
            for rel in rel_sec.iter_relocations():
                sym = symtab.get_symbol(rel["r_info_sym"])
                sec_idx = sym["st_shndx"]
                sec = elf.get_section(sec_idx) if isinstance(sec_idx, int) else None
                sec_name = sec.name if sec else ""
                if sec_name not in sec_bases:
                    raise RuntimeError(f"Unsupported relocation section: {sec_name}")
                target_addr = sec_bases[sec_name] + sym["st_value"]
                off = rel["r_offset"]
                rtype = rel["r_info_type"]
                if rtype == 2:  # R_ARM_ABS32
                    addend = struct.unpack_from("<I", payload, off)[0]
                    struct.pack_into("<I", payload, off, (target_addr + addend) & 0xFFFFFFFF)
                elif rtype in (10, 47):  # R_ARM_THM_CALL / THM_JUMP24
                    payload[off:off + 4] = make_bl(CAVE + off, target_addr & ~1)
                else:
                    raise RuntimeError(f"Unsupported reloc type {rtype} for {sym.name}")

    payload_bytes = bytes(payload)
    payload_bin.write_bytes(payload_bytes)
    info = {
        "hook_call": f"0x{CALL:08x}",
        "payload_address": f"0x{CAVE:08x}",
        "hook_entry": f"0x{hook_entry:08x}",
        "payload_bytes": len(payload_bytes),
        "payload_sha256": sha256(payload_bytes),
        "sections": {k: f"0x{v:08x}" for k, v in sec_bases.items()},
    }
    return payload_bytes, hook_entry, info


def patch_postboot3(pb3_in: Path, pb3_out: Path, payload: bytes, hook_entry: int) -> str:
    pb3 = bytearray(pb3_in.read_bytes())
    call_off = CALL - MODULE
    expected_orig_bl = make_bl(CALL, ORIGINAL_GETTER)
    assert pb3[call_off:call_off + 4] == expected_orig_bl, "Original BL mismatch in 07_postboot3.bin"
    cave_off = CAVE - MODULE
    assert pb3[cave_off:cave_off + len(payload)] == b"\xff" * len(payload), "Cave not empty (expected 0xFF)"
    pb3[call_off:call_off + 4] = make_bl(CALL, hook_entry & ~1)
    pb3[cave_off:cave_off + len(payload)] = payload
    pb3_out.write_bytes(pb3)
    return sha256(pb3)


def patch_osdover(osd_in: Path, osd_out: Path) -> dict:
    osd = bytearray(osd_in.read_bytes())
    applied = []
    for off, slot_bytes, old_str, new_str in UI_PATCHES:
        expected = old_str.encode("utf-16-le")
        cur = osd[off:off + len(expected)]
        new_enc = new_str.encode("utf-16-le")
        assert len(new_enc) <= slot_bytes, f"UI string too long @ 0x{off:06x}"
        if cur == expected:
            osd[off:off + slot_bytes] = new_enc + b"\x00" * (slot_bytes - len(new_enc))
            applied.append({"offset": f"0x{off:06x}", "old": old_str, "new": new_str})
        elif osd[off:off + len(new_enc)] == new_enc:
            applied.append({"offset": f"0x{off:06x}", "old": old_str, "new": new_str, "already_patched": True})
        else:
            raise RuntimeError(f"Unexpected UTF-16LE UI string @ 0x{off:06x}")
    osd_out.write_bytes(osd)
    return {"sha256": sha256(osd), "ui_patches": applied}


def main() -> None:
    root = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description="Build standalone S5 V2.9 LUT direct-output patch")
    parser.add_argument("--hook-c", type=Path, default=root / "src/hook.c")
    parser.add_argument("--postboot3-in", type=Path, default=None, help="Decrypted factory 07_postboot3.bin")
    parser.add_argument("--osdover-in", type=Path, default=None, help="Decrypted factory 20_osdover.bin")
    parser.add_argument("--out-dir", type=Path, default=root / "out")
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    payload, hook_entry, pb3_info = compile_and_link_payload(args.hook_c, args.out_dir)
    manifest: dict = {"07_postboot3": pb3_info}

    if args.postboot3_in is not None:
        pb3_sha = patch_postboot3(args.postboot3_in, args.out_dir / "07_postboot3.bin", payload, hook_entry)
        manifest["07_postboot3"]["postboot3_sha256"] = pb3_sha
        print(f"Patched 07_postboot3.bin -> {args.out_dir / '07_postboot3.bin'}")

    if args.osdover_in is not None:
        manifest["20_osdover"] = patch_osdover(args.osdover_in, args.out_dir / "20_osdover.bin")
        print(f"Patched 20_osdover.bin   -> {args.out_dir / '20_osdover.bin'}")

    manifest_path = args.out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Built payload.bin ({len(payload)} bytes @ {pb3_info['payload_address']}, entry {pb3_info['hook_entry']})")


if __name__ == "__main__":
    main()
