#!/usr/bin/env python3
"""Unicorn ARM verification suite for the standalone S5 V2.9 LUT patch (real DC-S5 hardware specs)."""

from __future__ import annotations

import argparse
import json
import struct
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm_const import (
    UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R4, UC_ARM_REG_R5,
    UC_ARM_REG_R6, UC_ARM_REG_R7, UC_ARM_REG_R8, UC_ARM_REG_R9,
    UC_ARM_REG_R10, UC_ARM_REG_R11, UC_ARM_REG_SP,
)

DESCRIPTOR = 0x8E000000
STACK = 0x8F000000
Y_ADDR, C_ADDR = 0x90000000, 0x92000000
OCTANT_BASE_OFFSETS = (0, 125, 225, 325, 405, 505, 585, 665)


def build_synthetic_beef_lut9_invert(program_bytes: bytes) -> bytes:
    """Build a real-format 9^3 0xBEEF octant LUT (2,920 bytes, 0x86E39EB4 remap) that inverts RGB."""
    oct_off = 0x86E39EB4 - 0x86280000
    entries = [(0, 0)] * 729
    for b in range(9):
        for g in range(9):
            for r in range(9):
                tnum, idx = struct.unpack_from("<HH", program_bytes, oct_off + (g * 81 + b * 9 + r) * 4)
                slot = OCTANT_BASE_OFFSETS[tnum] + idx
                r6 = 63 - ((r * 63 + 4) // 8)
                g6 = 63 - ((g * 63 + 4) // 8)
                b6 = 63 - ((b * 63 + 4) // 8)
                w0 = (r6 & 0x3F) | ((b6 & 0x3F) << 6) | ((g6 & 0x0F) << 12)
                w1 = (g6 >> 4) & 0x03
                entries[slot] = (w0, w1)
    buf = bytearray(struct.pack("<HH", 0xBEEF, 1))
    for w0, w1 in entries:
        buf += struct.pack("<HH", w0, w1)
    assert len(buf) == 2920
    return bytes(buf)


def run_case(
    image: bytes, patched_pb3: bytes, payload: bytes, call: int, cave: int,
    width: int, height: int, stride: int,
    view_assist_type: int, lut_id: int, mist_grain_en: int = 0,
    with_slot1_buf: bool = False, max_insns: int = 120000,
):
    resume = call + 4
    uc = Uc(UC_ARCH_ARM, UC_MODE_ARM)
    uc.mem_map(0x86000000, 0x02000000)
    uc.mem_write(0x86280000, image)
    uc.mem_write(0x87707000, patched_pb3[:0x2F0000])
    uc.mem_write(cave, payload)
    uc.mem_write(call, patched_pb3[call - 0x87707000:call - 0x87707000 + 4])

    uc.mem_map(0x08BDC000, 0x1000)
    uc.mem_write(0x08BDC310, struct.pack("<II", view_assist_type, mist_grain_en))
    uc.mem_write(0x08BDC330, struct.pack("<I", lut_id))

    uc.mem_map(0x062B0000, 0x10000)
    uc.mem_map(0x08A9D000, 0x1000)
    if with_slot1_buf:
        slot1_addr = 0x062B7000
        uc.mem_write(0x08A9D47C + 4, struct.pack("<I", slot1_addr))
        uc.mem_write(slot1_addr, build_synthetic_beef_lut9_invert(image))

    uc.mem_map(0x0B3D0000, 0x10000)
    uc.mem_map(DESCRIPTOR, 0x20000)
    uc.mem_map(STACK + 0xE000, 0x1000)  # Strict 4 KB stack guard
    uc.mem_map(Y_ADDR, 0x1800000)
    uc.mem_map(C_ADDR, 0x1800000)

    plane_sz = stride * height
    data = bytearray(0x38)
    struct.pack_into("<IIHHIIHHHHI", data, 0, Y_ADDR, plane_sz, stride, height,
                     C_ADDR, plane_sz, stride, height, 0, 0, 0)
    struct.pack_into("<HHI", data, 0x1C, width, height, 2)
    uc.mem_write(0x0B3D4224, bytes(data))
    uc.mem_write(Y_ADDR, bytes([100]) * (stride * 2))
    uc.mem_write(C_ADDR, bytes([0]) * (stride * 2))  # Real signed int8_t neutral UV = 0x00

    uc.reg_write(UC_ARM_REG_SP, STACK + 0xEFF0)
    uc.reg_write(UC_ARM_REG_R0, 1)
    uc.reg_write(UC_ARM_REG_R1, DESCRIPTOR)
    for reg in (UC_ARM_REG_R4, UC_ARM_REG_R5, UC_ARM_REG_R6, UC_ARM_REG_R7,
                UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_R10, UC_ARM_REG_R11):
        uc.reg_write(reg, 0x12345678)

    stopped = []

    def stop_on_return(uc_inst, address, size, user):
        if address == resume:
            stopped.append(address)
            uc_inst.emu_stop()

    uc.hook_add(UC_HOOK_CODE, stop_on_return, begin=resume, end=resume)
    uc.emu_start(call | 1, 0, count=max_insns)
    return bool(stopped), uc.reg_read(UC_ARM_REG_R0), bytes(uc.mem_read(Y_ADDR, 16)), bytes(uc.mem_read(C_ADDR, 16))


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify standalone S5 V2.9 LUT patch in Unicorn ARM")
    parser.add_argument("--program", type=Path, required=True, help="Decrypted 03_program.bin")
    parser.add_argument("--postboot3", type=Path, required=True, help="Patched 07_postboot3.bin")
    parser.add_argument("--payload", type=Path, required=True, help="Compiled payload.bin")
    parser.add_argument("--manifest", type=Path, required=True, help="manifest.json from build_lut_patch.py")
    args = parser.parse_args()

    m = json.loads(args.manifest.read_text())["07_postboot3"]
    call, cave = int(m["hook_call"], 16), int(m["payload_address"], 16)
    image = args.program.read_bytes()
    pb3 = args.postboot3.read_bytes()
    payload = args.payload.read_bytes()

    ok, r0, y0, c0 = run_case(image, pb3, payload, call, cave, 6000, 4000, 6016, 0, 0)
    assert ok and r0 == 0 and y0 == bytes([100]) * 16 and c0 == bytes([0]) * 16
    print("PASS Case 1 (disabled, 4KB stack): returned cleanly, pixels untouched")

    ok, r0, y0, c0 = run_case(image, pb3, payload, call, cave, 640, 480, 640, 1, 0)
    assert ok and r0 == 0 and y0 == bytes([100]) * 16 and c0 == bytes([0]) * 16
    print("PASS Case 2 (thumbnail 640x480): skipped cleanly")

    _, _, y_pure, c_pure = run_case(image, pb3, payload, call, cave, 6000, 4000, 6016, 1, 0, 0, False, 15000000)
    assert y_pure == bytes([108]) * 16 and c_pure[0] == 253 and c_pure[1] == 3
    print(f"PASS Case 3a (slot 0 pure 17^3 tetra, signed UV): Y={list(y_pure[:4])}, rawUV=({c_pure[0]},{c_pure[1]})")

    _, _, y_grain, _ = run_case(image, pb3, payload, call, cave, 6000, 4000, 6016, 1, 0, 1, False, 15000000)
    assert y_grain != bytes([100]) * 16 and len(set(y_grain)) > 1
    print(f"PASS Case 3b (slot 0 LUT + 2D Mist/Grain, 4KB stack): Y[0:8]={list(y_grain[:8])}")

    _, _, y_s1, _ = run_case(image, pb3, payload, call, cave, 6000, 4000, 6016, 1, 1, 0, True, 15000000)
    assert 150 <= y_s1[0] <= 160 and len(set(y_s1)) == 1
    print(f"PASS Case 4 (slot 1 @ 0x062B7000 9^3 octant 0xBEEF): Y[0:8]={list(y_s1[:8])}")

    _, _, y_65, _ = run_case(image, pb3, payload, call, cave, 6000, 2208, 6016, 1, 4, 0, False, 15000000)
    assert y_65 == y_pure
    print(f"PASS Case 5 (native 65:24 6000x2208):      Y={list(y_65[:4])}")

    _, _, y_11, _ = run_case(image, pb3, payload, call, cave, 4000, 4000, 4032, 1, 0, 0, False, 15000000)
    assert y_11 == y_pure
    print(f"PASS Case 6 (1:1 64B-aligned stride=4032): Y={list(y_11[:4])}")

    _, _, y_s65, _ = run_case(image, pb3, payload, call, cave, 2400, 888, 2432, 1, 0, 1, False, 15000000)
    assert y_s65 != bytes([100]) * 16 and len(set(y_s65)) > 1
    print(f"PASS Case 7 (S-size 65:24 2400x888):       Y[0:8]={list(y_s65[:8])}")


if __name__ == "__main__":
    main()
